﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyDescription("GitExtensions Bug Reporter")]

[assembly: InternalsVisibleTo("BugReporter.Tests")]
[assembly: InternalsVisibleTo("BugReporter.IntegrationTests")]
[assembly: InternalsVisibleTo("TranslationApp")]
