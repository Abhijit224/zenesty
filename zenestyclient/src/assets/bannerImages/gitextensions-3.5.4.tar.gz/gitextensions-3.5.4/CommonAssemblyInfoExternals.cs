﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyProduct("Git Extensions")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("33.33.33")]
[assembly: AssemblyFileVersion("33.33.33")]
[assembly: AssemblyInformationalVersion("33.33.33")]

// Disable CLS compliance. See https://github.com/gitextensions/gitextensions/issues/4710
[assembly: CLSCompliant(isCompliant: false)]

// Setting ComVisible to false makes the types in this assembly not visible
// to COM components.  If you need to access a type in this assembly from
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]
