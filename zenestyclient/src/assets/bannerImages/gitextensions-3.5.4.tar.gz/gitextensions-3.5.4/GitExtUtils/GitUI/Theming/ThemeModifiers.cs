﻿using System;

namespace GitExtUtils.GitUI.Theming
{
    public static class ThemeVariations
    {
        public const string Colorblind = "colorblind";
        public static readonly string[] None = Array.Empty<string>();
    }
}
