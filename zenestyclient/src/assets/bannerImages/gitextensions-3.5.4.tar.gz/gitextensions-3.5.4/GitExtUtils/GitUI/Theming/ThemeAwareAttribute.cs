﻿using System;

namespace GitExtUtils.GitUI.Theming
{
    [AttributeUsage(AttributeTargets.Class)]
    public class ThemeAwareAttribute : Attribute
    {
    }
}
