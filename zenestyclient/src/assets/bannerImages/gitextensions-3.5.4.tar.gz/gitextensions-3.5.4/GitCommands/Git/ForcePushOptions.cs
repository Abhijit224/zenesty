namespace GitCommands.Git
{
    public enum ForcePushOptions
    {
        DoNotForce = 0,
        Force,
        ForceWithLease,
    }
}
