﻿namespace GitCommands.Git
{
    public enum GitBisectOption
    {
        Good,
        Bad,
        Skip
    }
}
