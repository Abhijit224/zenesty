//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GitExtensionsShellEx.rc
//
#define IDS_PROJNAME                    100
#define IDR_GITEXTENSIONSSHELLEX        101
#define IDI_GITEXTENSIONS               201
#define IDI_ICONADDED                   202
#define IDI_ICONBROWSEFILEEXPLORER      203
#define IDI_ICONBRANCHCREATE            204
#define IDI_ICONBRANCHCHECKOUT          205
#define IDI_ICONREVISIONCHECKOUT        206
#define IDI_ICONABOUT                   208
#define IDI_ICONCLONEREPOGIT            209
#define IDI_ICONCOMMIT                  210
#define IDI_ICONFILEHISTORY             211
#define IDI_ICONPULL                    212
#define IDI_ICONPUSH                    213
#define IDI_ICONTRESETFILETO            214
#define IDI_ICONSETTINGS                215
#define IDI_ICONVIEWCHANGES             216
#define IDI_ICONSTASH                   217
#define IDI_ICONCREATEREPOSITORY        218
#define IDI_ICONPATCHAPPLY              219

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        220
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
