﻿namespace GitUI.BranchTreePanel.Interfaces
{
    public interface ICanRename
    {
        bool Rename();
    }
}
