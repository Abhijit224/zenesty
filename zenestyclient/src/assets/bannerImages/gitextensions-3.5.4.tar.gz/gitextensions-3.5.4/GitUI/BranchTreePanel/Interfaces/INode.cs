﻿namespace GitUI.BranchTreePanel.Interfaces
{
    /// <summary>
    /// Used only to hide <see cref="RepoObjectsTree.Node"/> for unit tests
    /// </summary>
    public interface INode
    {
    }
}
