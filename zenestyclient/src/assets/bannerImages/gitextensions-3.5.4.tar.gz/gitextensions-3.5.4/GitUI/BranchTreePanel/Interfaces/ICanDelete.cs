﻿namespace GitUI.BranchTreePanel.Interfaces
{
    public interface ICanDelete
    {
        bool Delete();
    }
}
