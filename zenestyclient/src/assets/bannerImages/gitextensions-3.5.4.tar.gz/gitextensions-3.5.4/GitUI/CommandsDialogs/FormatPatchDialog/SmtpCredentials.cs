﻿using System.Windows.Forms;

namespace GitUI.CommandsDialogs.FormatPatchDialog
{
    public partial class SmtpCredentials : Form
    {
        public SmtpCredentials()
        {
            InitializeComponent();
        }
    }
}
