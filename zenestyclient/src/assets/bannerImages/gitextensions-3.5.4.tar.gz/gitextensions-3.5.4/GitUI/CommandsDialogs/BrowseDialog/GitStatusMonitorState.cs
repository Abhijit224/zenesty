﻿namespace GitUI.CommandsDialogs.BrowseDialog
{
    public enum GitStatusMonitorState
    {
        Stopped = 0,
        Running,
        Inactive,
        Paused
    }
}
